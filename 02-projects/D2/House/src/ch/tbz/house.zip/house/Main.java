package ch.tbz.house;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Picture pic = new Picture();
		pic.draw();
	}
}